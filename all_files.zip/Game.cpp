#include <cassert>
#include <utility>
#include "Game.h"

namespace Chess
{
	/////////////////////////////////////
	// DO NOT MODIFY THIS FUNCTION!!!! //
	/////////////////////////////////////
	Game::Game() : is_white_turn(true) {
		// Add the pawns
		for (int i = 0; i < 8; i++) {
			board.add_piece(Position('A' + i, '1' + 1), 'P');
			board.add_piece(Position('A' + i, '1' + 6), 'p');
		}

		// Add the rooks
		board.add_piece(Position( 'A'+0 , '1'+0 ) , 'R' );
		board.add_piece(Position( 'A'+7 , '1'+0 ) , 'R' );
		board.add_piece(Position( 'A'+0 , '1'+7 ) , 'r' );
		board.add_piece(Position( 'A'+7 , '1'+7 ) , 'r' );

		// Add the knights
		board.add_piece(Position( 'A'+1 , '1'+0 ) , 'N' );
		board.add_piece(Position( 'A'+6 , '1'+0 ) , 'N' );
		board.add_piece(Position( 'A'+1 , '1'+7 ) , 'n' );
		board.add_piece(Position( 'A'+6 , '1'+7 ) , 'n' );

		// Add the bishops
		board.add_piece(Position( 'A'+2 , '1'+0 ) , 'B' );
		board.add_piece(Position( 'A'+5 , '1'+0 ) , 'B' );
		board.add_piece(Position( 'A'+2 , '1'+7 ) , 'b' );
		board.add_piece(Position( 'A'+5 , '1'+7 ) , 'b' );

		// Add the kings and queens
		board.add_piece(Position( 'A'+3 , '1'+0 ) , 'Q' );
		board.add_piece(Position( 'A'+4 , '1'+0 ) , 'K' );
		board.add_piece(Position( 'A'+3 , '1'+7 ) , 'q' );
		board.add_piece(Position( 'A'+4 , '1'+7 ) , 'k' );
	}

	void Game::make_move(const Position& start, const Position& end) {
		/////////////////////////
		// [REPLACE THIS STUB] //
		/////////////////////////
	}

	/**
	 * Checks if the king piece is in check.
	 * @param white True if the king is white, false if black.
	 * @return True if the king is in check, false otherwise.
	 */
	bool Game::in_check(const bool& white) const {
		return board.checkChecker(white);
	}


	bool Game::in_mate(const bool& white) const {
		/////////////////////////
		// [REPLACE THIS STUB] //
		/////////////////////////
		return false;
	}

	/**
	 * Checks if the game is in stalemate.
	 * @param white True if the king is white, false if black.
	 * @return True if the game is in stalemate, false otherwise.
	 */
	bool Game::in_stalemate(const bool& white) const {
		std::vector<std::pair<Position, const Piece*>> colorGroup =
		board.piecesByColor(white);
		const Piece* p;
		Position start;
		for (std::vector<std::pair<Position, const Piece*>>::const_iterator it =
			colorGroup.begin(); it != colorGroup.end(); ++it) {
			p = it->second;
			start = it->first;
			// run through all spots on the board
			for (char x = 'A'; x <= 'H'; ++x) {
				for (char y = '1'; y <= '8'; ++y) {
					Position end(x, y);
					// check if the moves would still be legal
					if (p->legal_move_shape(start, end)) {
						Game simulation = *this;
						simulation.make_move(start, end);
						// if after legal move, and not in check, that means
						// there are valid moves left
						if (!simulation.in_check(white)) return false;
					}
				}
			}
		}
		return true; // no legal moves left because they would all result in a check
	}

    // Return the total material point value of the designated player
    int Game::point_value(const bool& white) const {
		/////////////////////////
		// [REPLACE THIS STUB] //
		/////////////////////////
        return -1;
    }


      std::istream& operator>> (std::istream& is, Game& game) {
		/////////////////////////
		// [REPLACE THIS STUB] //
		/////////////////////////
		return is;
	}

    /////////////////////////////////////
    // DO NOT MODIFY THIS FUNCTION!!!! //
    /////////////////////////////////////
	std::ostream& operator<< (std::ostream& os, const Game& game) {
		// Write the board out and then either the character 'w' or the character 'b',
		// depending on whose turn it is
		return os << game.board << (game.turn_white() ? 'w' : 'b');
	}
}
