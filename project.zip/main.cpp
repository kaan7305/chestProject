#include <fstream>
#include <iostream>
#include <ostream>
#include <string>
#include <sstream>
#include <cassert>
#include "Exceptions.h"
#include "Game.h"

void show_commands() {
	std::cout << "List of commands:" << std::endl;
	std::cout << "\t'?':            show this list of options" << std::endl;
	std::cout << "\t'Q':            quit the game" << std::endl;
	std::cout << "\t'L' <filename>: load a game from the specified file" << std::endl;
	std::cout << "\t                <filename> is the name of the file to read from" <<std::endl;
	std::cout << "\t'S' <filename>: save a game to the specified file" << std::endl;
	std::cout << "\t                <filename> is the name of the file to write to" <<std::endl;
	std::cout << "\t'M' <move>:     try to make the specified move" << std::endl;
	std::cout << "\t                <move> is a four character string giving the" << std::endl;
	std::cout << "\t                column (['A'-'H']), row ('1'-'8') of the start position" << std::endl;
	std::cout << "\t                followed by the column and row of the end position" << std::endl;
}

int main(int argc, char* argv[]) {
	Chess::Game game;

	// Display command options
	show_commands();

	// Keep playing until the game is over
	bool game_over = false;

	while(!game_over) {

		std::string line;
		std::cout << "Next command: ";
		if (!std::getline(std::cin, line))
		{
			break; // Exit cleanly if input file ends
		}
		std::string choice;
		std::istringstream iss(line);
		iss >> choice;

		if(choice.empty() || choice.length() != 1) 
		{
			break;

		}
	

		// Validate that the command is a single character
		if (choice.length() != 1) {
			std::cerr << "Action specifier must be a single character, but length(" <<
			  choice << ") = " << choice.length() << std::endl;

		} else {
			// Process the different commands
			switch (choice[0]) {
			case '?':
				// Show the commands
				show_commands();
				break;
			case 'Q': case 'q':
				// Quit the game
				game_over = true;
				break;
			case 'L': case 'l': {
				// Load a game from a file
        // exit the program with return code -1 if an exception is caught here
				std::string argument;
				iss >> argument;;
				std::ifstream ifs;
			try {
				ifs.open( argument );
				if (!ifs.is_open()) throw Chess::Exception("Failed to open " + argument);
				ifs >> game;
				ifs.close();
			}
			catch (Chess::Exception& e) {
				std::cerr << "ERROR: " << e.what() << std::endl;
				return -1;
			}
				// Check that the game is valid
				assert(game.is_valid_game());
				break;
			}
			case 'S': case 's': {
				// Write a game to a file
				std::string argument;
				iss >> argument;
				std::ofstream ofs;
				ofs.open( argument );
				ofs << game;
				ofs.close();
				break;
			}
			case 'M': case 'm': {
				// Make a move
				std::string argument;
				iss >> argument;
				// Validate that the move is correctly specified
				if (argument.length() != 4) {
					std::cerr <<
					  "Move specifier must be four characters, but length(" <<
					  argument << " ) = " << argument.length() << std::endl;
				// And make the move
				} else {
					try {
						game.make_move(std::make_pair(argument[0], argument[1]),
									std::make_pair(argument[2], argument[3]));
					}
					catch (Chess::Exception& e) {
						std::cerr << "Could not make move: " << e.what() << std::endl;
					}
				}
				break;
			}
			default:
				// Unrecognized command
				std::cerr << "Invalid action '" << choice << "'" << std::endl;
			}

			if (!game_over) {
				// Display the board
				game.display();
	
				bool turnWhite = game.turn_white();
				// Indicate whose turn it is
				if (turnWhite) {
					std::cout << "White's move." << std::endl;
				} else {
					std::cout << "Black's move." << std::endl;
				}
	
				// Indicate current player's material point value
				std::cout << "Material point value: "
						  << game.point_value(turnWhite) << std::endl;
	
				bool isCheck = game.in_check(turnWhite);
				bool isMate  = isCheck && game.in_mate(turnWhite);
				bool isStale = !isMate && !isCheck && game.in_stalemate(turnWhite);
	
				if (isMate) {
					std::cout << "Checkmate! Game over." << std::endl;
					game_over = true;
				} else if (isCheck) {
					std::cout << "You are in check!" << std::endl;
				} else if (isStale) {
					std::cout << "Stalemate! Game over." << std::endl;
					game_over = true;
				}
			}
		}
	}

	// Write out the state of the game to a file
	if (argc > 1) {
		std::ofstream ofs;
		ofs.open(argv[1]);
		ofs << game;
		ofs.close();
	}

	return 0;
}

